CREATE DATABASE db_locacar;
